# Courier-Management-System-
Courier Management System gives all information regarding the every Courier in the systems. The system has two user role one is customer, who can track package using randomly generated number and another role is  manager who can add packages and customer details. All of them there is a primary role is admin who can add branches and location in the system
